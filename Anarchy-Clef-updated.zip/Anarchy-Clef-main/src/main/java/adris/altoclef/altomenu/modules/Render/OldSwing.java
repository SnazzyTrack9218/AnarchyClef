package adris.altoclef.altomenu.modules.Render;

import adris.altoclef.altomenu.Mod;


//Mixin
public class OldSwing extends Mod {


    public OldSwing() {
        super("OldSwing", "Funne", Mod.Category.RENDER);
    }

}
