package adris.altoclef.altomenu.modules.Bot;

public class AutoTotem {
    //TODO implement
}
