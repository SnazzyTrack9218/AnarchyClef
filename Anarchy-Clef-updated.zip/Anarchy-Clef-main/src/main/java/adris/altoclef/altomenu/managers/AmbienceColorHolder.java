package adris.altoclef.altomenu.managers;

public class AmbienceColorHolder {
    public static int currentColor = 0x00FF00; // Default green
}