package adris.altoclef.altomenu.modules.Bot;

import adris.altoclef.altomenu.Mod;
import adris.altoclef.altomenu.settings.BooleanSetting;
import adris.altoclef.altomenu.settings.NumberSetting;
import adris.altoclef.eventbus.EventBus;
import adris.altoclef.eventbus.EventHandler;
import adris.altoclef.eventbus.events.ChatMessageEvent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//Todo
// - Add Player Whitelist
// - Support Private Messaging
// - Integrate Discord Bot Support
// - add AutoSnitch (Automatically Snitches on players that Change to Creative Mode or Players that hold out Illegal Items)
// - Support GreenText messages for Anarchy Servers
// - Support Running Baritone / AltoClef Commands (With a User Whitelist)
// - Support Toggling Modules with Chat (With a User Whitelist)
// - Support BlackListing Players
// - Add AntiSpam to stop bot from getting kicked from AntiSpam Plugins
// - Send Errors to Chat (with private messaging support)
// - Send Chat Screenshots to Discord Webhook
// - Screenshot Command (Screenshots then uploads to img.bb or imgur and sends image link to chat)
// - Add GithubSearch Command to search for Github Repo's using GithubAPI
// - Support Chatting with a Twitch Chat using LLM's like DeepSeek or ChatGPT
// - Support Chatting with a Discord Server using LLM's like DeepSeek or ChatGPT
// - Support Chatting in Minecraft Chat using LLM's like DeepSeek or ChatGPT
// - Add Magic8Ball Command
// - Add ServerFinder Command (Scans for Server's on a certain IP Address)
// - Add ServerStatus Commmand (Check's if a Server is current online and gets their current PlayerCount)
// - Add ServerList Command (Lists all Servers found through ServerFinder by sending a Chat Message with link to a list sent on PasteBin)

public class ChatBot extends Mod {
    public static ChatBot instance;
    public ChatBot() {
        super("ChatBot", "ChatBot", Mod.Category.BOT);
        instance = this;
        EventBus.subscribe(ChatMessageEvent.class, this::onChatMessage);
    }

    NumberSetting messageDelay = new NumberSetting("Message Delay (ticks)", 1, 999, 100, 1);
    BooleanSetting greentext = new BooleanSetting("GreenText", false);
    BooleanSetting announcer = new BooleanSetting("Announcer", false);

    double delay = 0;

    @Override
    public void onEnable() {
        System.out.println("ChatBot Enabled");
        addAnnouncerMessage();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        System.out.println("ChatBot Disabled");
        removeAnnouncerMessage();
        super.onDisable();
    }

    private boolean hasSentMessageAlready = false;

    @EventHandler
    public boolean onShitTick() {
        delay++;
        if (delay > messageDelay.getValuefloat()) delay = 0; //this kills performance probably FUCK!
        boolean justDied = !mc.player.isAlive() && !hasSentMessageAlready;
        boolean justRespawned = mc.player.isAlive() && hasSentMessageAlready;
        if (justDied) {
            mc.player.networkHandler.sendChatMessage("Why is my only Job to die?");
            hasSentMessageAlready = true;
        } else if (justRespawned) {
            hasSentMessageAlready = false;
        }

        if (announcer.isEnabled() && (delay >= messageDelay.getValuefloat())) {
            Random random = new Random();
            int randomIndex = random.nextInt(announcerMessages.size());
            String randomMessage = announcerMessages.get(randomIndex);
            sendMessage(randomMessage);
        }
        return false;
    }

    @EventHandler
    public void onChatMessage(ChatMessageEvent event) {
        if (this.isEnabled()) {
            if (event.messageContent().startsWith("!")) {
                processCommand(event.messageContent().substring(1));
            }
            System.out.println("Received message: " + event.messageContent());
        }
    }

    public void processMessage(Text message) {

    }

    public void processCommand(String command) {
        //Check if it contains the command
        switch (command) {
            case "coords":
                sendMessage("Current coordinates: " + "X: " + Math.round(mc.player.getX()) + " Y: " + Math.round(mc.player.getY()) + " Z: " + Math.round(mc.player.getZ()));
                break;
            case "github":
                sendMessage("github.com/Volcan4436/Anarchy-Clef");
                break;

            //todo: Fix and Integrate Butler System
/*            case "kill":
                assert mc.player != null;
                mc.player.networkHandler.sendCommand("kill");
                break;*/
            case "help":
                // Handle the help command
                break;
            case "info":
                // Handle the info command
                break;
            default:
                // Handle unknown commands
                break;
        }
    }

    String prefix = "";

    private void sendMessage(String s) {
        //Send a Chat Message
        assert MinecraftClient.getInstance().player != null;
        if (greentext.isEnabled()) prefix = "> ";
        else prefix = "";
        MinecraftClient.getInstance().player.networkHandler.sendChatMessage(prefix + s);
    }


    private final List<String> announcerMessages = new ArrayList<>();




    public void addAnnouncerMessage() {
        assert mc.player != null;
        announcerMessages.add("I am holding " + mc.player.getMainHandStack().getName().getString());
        announcerMessages.add("I have " + Math.round(mc.player.getHealth()) + " health left");
        announcerMessages.add("I have " + mc.player.getHungerManager().getFoodLevel() + " food left");
        //Add More Here
    }

    public void removeAnnouncerMessage() {
        announcerMessages.clear();
    }
}
