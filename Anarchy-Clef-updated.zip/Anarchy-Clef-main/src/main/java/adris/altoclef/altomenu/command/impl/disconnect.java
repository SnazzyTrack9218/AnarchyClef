package adris.altoclef.altomenu.command.impl;

public class disconnect {
}
