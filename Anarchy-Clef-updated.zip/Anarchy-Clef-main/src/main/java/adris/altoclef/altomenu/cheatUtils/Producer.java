package adris.altoclef.altomenu.cheatUtils;

public interface Producer<T> {
    T create();
}