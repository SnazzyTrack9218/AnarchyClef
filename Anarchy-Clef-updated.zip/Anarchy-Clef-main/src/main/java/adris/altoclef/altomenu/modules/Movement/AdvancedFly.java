package adris.altoclef.altomenu.modules.Movement;

import adris.altoclef.altomenu.Mod;
import adris.altoclef.altomenu.cheatUtils.CMoveUtil;
import adris.altoclef.altomenu.settings.BooleanSetting;
import adris.altoclef.altomenu.settings.ModeSetting;
import adris.altoclef.altomenu.settings.NumberSetting;
import adris.altoclef.eventbus.EventHandler;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

import java.util.Objects;

// We Will Need the ability to change Settings of a Module with commands at some point
//todo:
// add ElytraPacket Spammer (Can Allow us to mess with older Anticheats)
// add BlockPhase Methods (MightBeUseful For CrystalPvP movement setup)
// add Stutter (Stutter our movement to mess with Anticheats)
// add GroundSpoof Spammer (Can help with FallDamage and might cause Disablers)
// add Blink
// add Elytra Packet Method (Similar to Meteor)
// add LongJump Style Methods
// add Standard Disabler Methods (KeepAlive, Transaction, PingSpoof, Blink, IncreaseYPositionSpam, GroundSpoof, AutoVoid *ForBedwarsServers*)
// add SlowFall Potion Effect Spoofer
// Add Strict Mode that uses a yawStep to slow your rotations that might help with bypassing
// add Option to start using a Fireball (For Bedwars)
// add Option to use with an elytra (for Custom Elytra Fly)
// Add Option to Start Fly Under a Block (For Legacy Anticheat Support)
// Add Option to Start Fly after Phasing into a Block (Similar to Old Hypixel Fly Methods) (For Legacy Anticheat Support)
// Add ClientServerSync that tries to keep your client synced with the Server with differnt methods so we don't get lag backs or have issues at high speed
public class AdvancedFly extends Mod {

    public AdvancedFly() {
        super("AdvancedFly", "Advanced Fly", Mod.Category.MOVEMENT);
    }

    int ticks = 0;
    int posAbuseTicks = 0;

    //Settings
    BooleanSetting spoofCanFly = new BooleanSetting("Ability", false);
    ModeSetting antiKick = new ModeSetting("Anti-Kick", "None", "None", "Glide", "Position", "Jump");
    BooleanSetting strafe = new BooleanSetting("Strafe", false);
    BooleanSetting damageBoost = new BooleanSetting("Damage-Boost", false);
    NumberSetting boostAmount = new NumberSetting("Boost-Amount", 0, 20, 2, 0.1);
    NumberSetting boostTicks = new NumberSetting("Boost-Ticks", 1, 20, 5, 1);
    ModeSetting flyMethod = new ModeSetting("Fly-Method", "Position", "Position", "Velocity", "None", "Dev");
    NumberSetting vertical = new NumberSetting("Vertical", 0.1, 10, 1, 0.1);
    NumberSetting horizontal = new NumberSetting("Horizontal", 0.1, 10, 1, 0.1);
    BooleanSetting forceRotation = new BooleanSetting("Force-Rotation", false);
    NumberSetting forceYaw = new NumberSetting("Force Yaw", 0, 360, 0, 0.1);
    NumberSetting forcePitch = new NumberSetting("Force Pitch", -90, 90, 0, 0.1);
    BooleanSetting gravity = new BooleanSetting("Gravity", true); //todo: create a GravityUtil
    BooleanSetting positionAbuse = new BooleanSetting("Position Abuse", false);
    NumberSetting positionAbuseTicks = new NumberSetting("Position Abuse Ticks", 1, 20, 3, 1);
    NumberSetting positionAbuseIntensity = new NumberSetting("Position Abuse Intensity", 0.1, 0.9, 0.3, 0.1);
    BooleanSetting isElytraFly = new BooleanSetting("Elytra Fly", false);
    BooleanSetting groundSpoof = new BooleanSetting("Ground Spoof", false);

    @EventHandler
    public boolean onShitTick() {
        //ElytraFly
        if (isElytraFly.isEnabled() && !mc.player.isFallFlying()) return false;

        // General
        assert mc.player != null;
        ticks++; //Keeps track of Ticks

        //Fly
        if (flyMethod.getMode() == "Position") {
            float yaw = mc.player.getYaw();
            double radians = Math.toRadians(yaw);
            double distance = horizontal.getValuefloat();

            // Calculate the offset based on the player's viewing direction
            double xOffset = -Math.sin(radians) * distance; // Calculate X offset based on yaw
            double zOffset = Math.cos(radians) * distance;  // Calculate Z offset based on yaw

            if (mc.options.jumpKey.isPressed()) {
                mc.player.updatePosition(mc.player.getX(), mc.player.getY() + vertical.getValuefloat(), mc.player.getZ());
            } else if (mc.options.sneakKey.isPressed()) {
                mc.player.updatePosition(mc.player.getX(), mc.player.getY() - vertical.getValuefloat(), mc.player.getZ());
            } else if (mc.options.forwardKey.isPressed()) {
                mc.player.updatePosition(mc.player.getX() + xOffset, mc.player.getY(), mc.player.getZ() + zOffset);
            } else if (mc.options.backKey.isPressed()) {
                mc.player.updatePosition(mc.player.getX() - xOffset, mc.player.getY(), mc.player.getZ() - zOffset);
            } else if (mc.options.leftKey.isPressed()) {
                mc.player.updatePosition(mc.player.getX() + zOffset, mc.player.getY(), mc.player.getZ() - xOffset);
            } else if (mc.options.rightKey.isPressed()) {
                mc.player.updatePosition(mc.player.getX() - zOffset, mc.player.getY(), mc.player.getZ() + xOffset);
            }
        }
        if (flyMethod.getMode().equals("Velocity")) {
            float yaw = mc.player.getYaw();
            double radians = Math.toRadians(yaw);
            double distance = horizontal.getValuefloat();

            // Calculate velocity components based on yaw
            double xVelocity = -Math.sin(radians) * distance;
            double zVelocity = Math.cos(radians) * distance;
            double yVelocity = 0.0;

            if (mc.options.jumpKey.isPressed()) {
                yVelocity = vertical.getValuefloat(); // Move upwards
            } else if (mc.options.sneakKey.isPressed()) {
                yVelocity = -vertical.getValuefloat(); // Move downwards
            }

            if (mc.options.forwardKey.isPressed()) {
                mc.player.setVelocity(xVelocity, yVelocity, zVelocity);
            } else if (mc.options.backKey.isPressed()) {
                mc.player.setVelocity(-xVelocity, yVelocity, -zVelocity);
            } else if (mc.options.leftKey.isPressed()) {
                mc.player.setVelocity(zVelocity, yVelocity, -xVelocity);
            } else if (mc.options.rightKey.isPressed()) {
                mc.player.setVelocity(-zVelocity, yVelocity, xVelocity);
            } else {
                mc.player.setVelocity(0, yVelocity, 0); // Stop movement if no key is pressed (except for vertical movement)
            }
        }


        //Strafe
        if (strafe.isEnabled()) {
            CMoveUtil.strafe();
        }

        //AntiKick
        // todo:
        //  - Add DelayOption
        //  - Add GroundSpoofOption
        if (antiKick.getMode() == "Glide") {
            if (!mc.player.isOnGround() && ticks >= 20) {
                mc.player.setVelocity(mc.player.getVelocity().x, -0.3, mc.player.getVelocity().z);
            }
        }
        else if (antiKick.getMode() == "Position") {
            if (!mc.player.isOnGround() && ticks >= 20) {
                mc.player.updatePosition(mc.player.getX(), mc.player.getY() - 0.3, mc.player.getZ());
            }
        }
        else if (antiKick.getMode() == "Jump") {
            if (!mc.player.isOnGround() && ticks >= 20) {
                mc.player.jump();
            }
        }

        //Spoof Fly
        // todo:
        //  - Add Flight Speed Option
        if (!mc.player.isCreative() && spoofCanFly.isEnabled() && !mc.player.getAbilities().allowFlying) mc.player.getAbilities().allowFlying = true;
        else if (!spoofCanFly.isEnabled() && !mc.player.isCreative()) mc.player.getAbilities().allowFlying = false;

        //Yaw & Pitch
        // todo:
        //  - Add ServerSide Spoofer Option
        if (forceRotation.isEnabled()) {
            mc.player.setYaw(forceYaw.getValuefloat());
            mc.player.setPitch(forcePitch.getValuefloat());
        }

        //DamageBoost
        // todo:
        //  - Add Setback Detection
        //  - Add BoostMethod (Position, Velocity, PacketAbuse)
        if (damageBoost.isEnabled() && mc.player.hurtTime < boostTicks.getValueInt()) {
            float yaw = mc.player.getYaw();
            double radians = Math.toRadians(yaw);
            double power = boostAmount.getValuefloat();

            // Calculate velocity components based on yaw
            double xVelocity = -Math.sin(radians) * power;
            double zVelocity = Math.cos(radians) * power;

            mc.player.setVelocity(xVelocity, mc.player.getVelocity().y, zVelocity);
        }

        //Gravity (We really need to code a util to fix the problem of it not making sense when reading this code)
        // Update player gravity to match current gravity setting
        // setNoGravity (false = gravity enabled, true = gravity disabled)
        if (gravity.isEnabled() && mc.player.hasNoGravity()) {
            mc.player.setNoGravity(false); // enable gravity
        } else if (!gravity.isEnabled() && !mc.player.hasNoGravity()) {
            mc.player.setNoGravity(true); // disable gravity
        }

        // Position Abuse
        // todo:
        //  - Implement Different Abuse Methods
        //  - Improve Delay Mechanism
        //  - Add TPS Sync (Sync the Position Abuse to run during a Tick with 2 options ServerSide Tick or ClientSided Tick)
        if (positionAbuse.isEnabled()) {
            posAbuseTicks++; // Increment position abuse ticks

            if (posAbuseTicks >= positionAbuseTicks.getValueInt()) {
                if (!mc.player.isOnGround() && CMoveUtil.isMoving()) {
                    // Get player yaw and convert to radians
                    float yaw = mc.player.getYaw();
                    double radians = Math.toRadians(yaw);

                    // Calculate forward direction
                    double xOffset = -Math.sin(radians);
                    double zOffset = Math.cos(radians);

                    // Interpolate based on intensity and random factor
                    double random = Math.random() * 10;  // Generate random number
                    double interp = random * positionAbuseIntensity.getValuefloat();

                    // Normalize the direction vector
                    double length = Math.sqrt(xOffset * xOffset + zOffset * zOffset);
                    if (length != 0) {
                        xOffset /= length;
                        zOffset /= length;
                    }

                    // Apply velocity in the yaw direction
                    mc.player.setVelocity(
                            mc.player.getVelocity().x + xOffset * interp,
                            mc.player.getVelocity().y,
                            mc.player.getVelocity().z + zOffset * interp
                    );
                }
            }

            // Reset counter to loop
            if (posAbuseTicks > positionAbuseTicks.getValueInt() + 1) {
                posAbuseTicks = 0;
            }
        }

/*        // Position Abuse
        if (positionAbuse.isEnabled()) {
            posAbuseTicks++; // Increment position abuse ticks
            double random = Math.random() * 10;  // Generate random number
            double interp = random * positionAbuseIntensity.getValuefloat(); // Interpolate based on intensity

            if (posAbuseTicks >= positionAbuseTicks.getValueInt()) {
                if (!mc.player.isOnGround() && CMoveUtil.isMoving()) {
                    mc.player.setVelocity(mc.player.getVelocity().x + interp, mc.player.getVelocity().y, mc.player.getVelocity().z + interp); // Testing
                }
            }
            if (posAbuseTicks > positionAbuseTicks.getValueInt() + 1) posAbuseTicks = 0;
        }*/


        if (groundSpoof.isEnabled()) Objects.requireNonNull(mc.getNetworkHandler()).sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true));

        return false;
    }

    @Override
    public void onEnable() {
        assert mc.player != null;
        ticks = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        assert mc.player != null;
        ticks = 0;
        if (!mc.player.isCreative() && mc.player.getAbilities().allowFlying) mc.player.getAbilities().allowFlying = false;
        super.onDisable();
    }
}
