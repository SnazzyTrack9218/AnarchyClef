package adris.altoclef.altomenu.modules.Bot;

public class BotReach {
    //TODO Hook into Baritone Settings
}
