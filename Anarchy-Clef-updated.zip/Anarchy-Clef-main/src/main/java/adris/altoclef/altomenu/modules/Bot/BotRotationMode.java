package adris.altoclef.altomenu.modules.Bot;

public class BotRotationMode {
    //TODO implement
    // @ChiefWarCry Please do the implementation
}
