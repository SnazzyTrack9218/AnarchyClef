package adris.altoclef.altomenu.modules.Render;

import adris.altoclef.altomenu.Mod;

//todo: implement Glint Colorizer

//Uses ItemStackMixin
public class ForceGlint extends Mod {

    public static ForceGlint Instance;

    public ForceGlint() {
        super("ForceGlint", "Funne", Mod.Category.RENDER);
        Instance = this;
    }
}
