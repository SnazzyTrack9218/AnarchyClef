package adris.altoclef.eventbus.events;

public class TitleScreenEntryEvent {
}
