package adris.altoclef.eventbus.events;

public class GameOverlayEvent {
    public String message;

    public GameOverlayEvent(String message) {
        this.message = message;
    }
}
