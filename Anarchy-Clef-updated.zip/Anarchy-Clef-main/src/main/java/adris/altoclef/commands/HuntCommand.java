package adris.altoclef.commands;

import adris.altoclef.AltoClef;
import adris.altoclef.commandsystem.Arg;
import adris.altoclef.commandsystem.ArgParser;
import adris.altoclef.commandsystem.Command;
import adris.altoclef.commandsystem.CommandException;
import adris.altoclef.tasks.entity.HuntPlayerTask;
import net.minecraft.client.MinecraftClient;

/**
 * Command that causes the bot to hunt a named player.  This command is
 * intended strictly for single‑player worlds, LAN sessions or privately hosted
 * testing servers.  It will pathfind to the specified player using Baritone,
 * equip any available armor, and attack until the target is dead.  Use
 * responsibly.
 */
public class HuntCommand extends Command {

    public HuntCommand() throws CommandException {
        super("hunt", "Hunt a player in single player/LAN worlds", new Arg(String.class, "username", null, 1));
    }

    @Override
    protected void call(AltoClef mod, ArgParser parser) throws CommandException {
        String username = parser.get(String.class);
        if (username == null || username.isBlank()) {
            mod.logWarning("Usage: /hunt <playerName>");
            finish();
            return;
        }
        // Ensure we only run this in single‑player or integrated server contexts.
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            // `isInSingleplayer` returns true for both single player and LAN worlds.
            if (client == null || !client.isInSingleplayer()) {
                mod.logWarning("/hunt can only be used in single player or private testing worlds.");
                finish();
                return;
            }
        } catch (Exception ignored) {
            // If anything goes wrong, err on the side of caution and refuse execution.
            mod.logWarning("Could not verify environment for /hunt command. Aborting for safety.");
            finish();
            return;
        }
        // Run our custom task.  When it finishes the command completes.
        mod.runUserTask(new HuntPlayerTask(username), this::finish);
    }
}