package adris.altoclef.experimental.AI.Core.Memory;

public class Homes {
}
