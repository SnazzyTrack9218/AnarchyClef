package adris.altoclef.tasks.Anarchy;

public class SafeHoleTask {
    //TODO implement
}
