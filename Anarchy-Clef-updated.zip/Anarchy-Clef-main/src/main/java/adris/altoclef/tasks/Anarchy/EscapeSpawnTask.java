package adris.altoclef.tasks.Anarchy;

public class EscapeSpawnTask {
    //TODO implement
}
