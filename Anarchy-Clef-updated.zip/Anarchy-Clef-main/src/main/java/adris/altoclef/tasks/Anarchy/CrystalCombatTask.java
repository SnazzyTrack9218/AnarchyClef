package adris.altoclef.tasks.Anarchy;

public class CrystalCombatTask {
    //TODO implement
}
