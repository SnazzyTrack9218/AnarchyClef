package adris.altoclef.tasks.Anarchy;

public class AvoidCrystalTask {
    //TODO implement
}
