package adris.altoclef.tasks.entity;

import adris.altoclef.AltoClef;
import adris.altoclef.tasks.misc.EquipArmorTask;
import adris.altoclef.tasksystem.Task;
import net.minecraft.item.Items;

/**
 * A task that aggressively hunts a specific player.  This task is designed
 * for offline testing scenarios such as single‑player or LAN worlds and will
 * automatically equip any armour available before engaging.  It wraps
 * {@link KillPlayerTask} and exposes a higher level of behaviour control.
 */
public class HuntPlayerTask extends Task {
    private final String _playerName;
    private Task _equipTask;
    private final KillPlayerTask _killTask;

    public HuntPlayerTask(String playerName) {
        _playerName = playerName;
        _killTask = new KillPlayerTask(playerName);
    }

    @Override
    protected void onStart(AltoClef mod) {
        // Reset our state so armour will be equipped on the first tick.
        _equipTask = null;
    }

    @Override
    protected Task onTick(AltoClef mod) {
        // Step 1: ensure we are wearing any available armour.  Use explicit
        // targets for all armour slots to maximise protection.  The
        // EquipArmorTask will fetch missing pieces if necessary via the
        // Catalogue system.
        if (_equipTask != null && !_equipTask.isFinished(mod)) {
            setDebugState("Equipping armour");
            return _equipTask;
        }
        if (_equipTask == null) {
            _equipTask = new EquipArmorTask(
                    Items.NETHERITE_HELMET,
                    Items.NETHERITE_CHESTPLATE,
                    Items.NETHERITE_LEGGINGS,
                    Items.NETHERITE_BOOTS,
                    Items.SHIELD
            );
            return _equipTask;
        }
        // Step 2: attack the player until they reach zero health.  The
        // underlying KillPlayerTask handles pathfinding and combat via
        // AbstractKillEntityTask.
        setDebugState("Hunting " + _playerName);
        return _killTask;
    }

    @Override
    public boolean isFinished(AltoClef mod) {
        // We finish when our kill task has completed.  If the player logs
        // out or cannot be located the kill task will also complete.
        return _killTask.isFinished(mod);
    }

    @Override
    protected void onStop(AltoClef mod, Task interruptTask) {
        // Propagate stop to our subtasks so they can clean up any state.
        if (_equipTask != null) {
            _equipTask.stop(mod, interruptTask);
        }
        _killTask.stop(mod, interruptTask);
    }

    @Override
    protected boolean isEqual(Task other) {
        if (other instanceof HuntPlayerTask task) {
            return task._playerName.equals(_playerName);
        }
        return false;
    }

    @Override
    protected String toDebugString() {
        return "Hunting player " + _playerName;
    }
}